﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace PR.WizPlant.Web.SystemModule.DataModelCenter
{
    public partial class OfficePlayer : System.Web.UI.Page
    {
        public string url = "";
        public string fileType = "";
        protected void Page_Load(object sender, EventArgs e)
        {
            url = Request["fileUri"];
            fileType = Path.GetExtension(url);


        }

        private string filePath = string.Empty;
        protected void PageOfficeCtrl1_Load(object sender, EventArgs e)
        {
            if (url != null)
            {
                try
                {
                    // 设置PageOffice组件服务页面
                    PageOfficeCtrl1.ServerPage = Request.ApplicationPath + "pageoffice/server.aspx";
                    // 设置保存文件页面
                    PageOfficeCtrl1.SaveFilePage = "SaveFile.aspx";
                    string fileGuidName = Guid.NewGuid().ToString().Replace("-", "") + Path.GetExtension(url.Replace("/", "\\"));

                    //downloadEntity.Url 文件网络路径
                    //downloadEntity.Path 文件本地保存地址
                    //downloadEntity.Progress 文件下载进度
                    System.Net.HttpWebRequest httpWebRequest1 = (System.Net.HttpWebRequest)System.Net.HttpWebRequest.Create(url);
                    System.Net.HttpWebResponse httpWebResponse1 = (System.Net.HttpWebResponse)httpWebRequest1.GetResponse();
                    long totalLength = httpWebResponse1.ContentLength;

                    string folderDir = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "pageoffice\\TempFiles");
                    if (!Directory.Exists(folderDir))
                    {
                        Directory.CreateDirectory(folderDir);
                    }

                    filePath = Path.Combine(folderDir, fileGuidName);

                    System.IO.Stream stream1 = httpWebResponse1.GetResponseStream();
                    System.IO.Stream stream2 = new System.IO.FileStream(filePath, System.IO.FileMode.Create);

                    byte[] by = new byte[5024];
                    int osize = stream1.Read(by, 0, (int)by.Length);
                    while (osize > 0)
                    {
                        stream2.Write(by, 0, osize);
                        osize = stream1.Read(by, 0, (int)by.Length);
                    }

                    stream2.Close();
                    stream1.Close();

                    if (filePath.Trim().EndsWith("docx", StringComparison.OrdinalIgnoreCase) ||
                        filePath.Trim().EndsWith("doc", StringComparison.OrdinalIgnoreCase))
                    {
                        // 打开文档
                        PageOfficeCtrl1.WebOpen(filePath, PageOffice.OpenModeType.docNormalEdit, "PR" +DateTime.Now.ToString("yyyyMMddHHmmss"));
                    }
                    else if (filePath.Trim().EndsWith("xls", StringComparison.OrdinalIgnoreCase) ||
                            filePath.Trim().EndsWith("xlsx", StringComparison.OrdinalIgnoreCase))
                    {
                        // 打开文档
                        PageOfficeCtrl1.WebOpen(filePath, PageOffice.OpenModeType.xlsNormalEdit, "PR" + DateTime.Now.ToString("yyyyMMddHHmmss"));
                    }
                    else
                    {
                        // 打开文档
                        PageOfficeCtrl1.WebOpen(filePath, PageOffice.OpenModeType.pptNormalEdit, "PR" + DateTime.Now.ToString("yyyyMMddHHmmss"));
                    }
                   
                    deleteTempFiles();
                }
                catch (Exception ex)
                {
                    LogHelper.WriteErrorLog(ex);
                }
                
             
            }
       
        }


        private void deleteTempFiles()
        {
            string folderDir = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "pageoffice\\TempFiles");
            DirectoryInfo directory =new DirectoryInfo(folderDir);
            foreach (var fileInfo in directory.GetFiles())
            {
                if (fileInfo.CreationTime < DateTime.Now.AddDays(-2))
                {
                    try
                    {
                        File.Delete(fileInfo.FullName);
                    }
                    catch (Exception ex)
                    {
                        LogHelper.WriteErrorLog(ex);
                    }
                   
                }
            }

        }

        protected void PageOfficeCtrl1_UnLoad(object sender, EventArgs e)
        {
            //try
            //{
            //    File.Delete(filePath);
            //}
            //catch (Exception)
            //{

            //}
            
        }
    }
}